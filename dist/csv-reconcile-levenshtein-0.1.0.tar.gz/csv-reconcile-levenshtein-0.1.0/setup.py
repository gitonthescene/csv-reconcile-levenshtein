# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['csv_reconcile_levenshtein']

package_data = \
{'': ['*']}

install_requires = \
['python-Levenshtein>=0.12.2,<0.13.0']

entry_points = \
{'csv_reconcile.scorers': ['levenshtein = csv_reconcile_levenshtein']}

setup_kwargs = {
    'name': 'csv-reconcile-levenshtein',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Douglas Mennella',
    'author_email': 'douglas.mennella@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
