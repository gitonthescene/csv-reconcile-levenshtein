
# Table of Contents

1.  [CSV Reconcile Levenshtein distance scoring plugin](#orgaad35af)


<a id="orgaad35af"></a>

# CSV Reconcile Levenshtein distance scoring plugin

A scoring plugin for [csv-reconcile](https://github.com/gitonthescene/csv-reconcile) using [Levenshtein distance](https://en.wikipedia.org/wiki/Levenshtein_distance).  See csv-reconcile for details.

